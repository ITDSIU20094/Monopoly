/**
 * Abstract class to represent the 'special' cells in monopoly
 */
public abstract class Special extends Cell {
    public Special(int ID, String name) {
        super(ID, name);
    }
}